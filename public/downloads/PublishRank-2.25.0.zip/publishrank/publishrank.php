<?php
/**
 * Plugin Name: PublishRank
 * Plugin URI: https://publishrankseo.vercel.app/
 * Description: Advanced SEO, News SEO, XML sitemaps, schema, redirects and robots controls for WordPress publishers.
 * Version: 2.25.0
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Author: Muhammad Umar Jabbar
 * Author URI: https://umarjaum.netlify.app
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: publishrank
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', static function () {
	load_plugin_textdomain( 'publishrank', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}, 1 );

// The plugin header above is the single source of truth for the version number.
$publishrank_header = get_file_data( __FILE__, array( 'Version' => 'Version' ), 'plugin' );
define( 'PUBLISHRANK_SEO_VERSION', ! empty( $publishrank_header['Version'] ) ? $publishrank_header['Version'] : '0.0.0' );
unset( $publishrank_header );
define( 'PUBLISHRANK_SEO_FILE', __FILE__ );
define( 'PUBLISHRANK_SEO_PATH', plugin_dir_path( __FILE__ ) );
define( 'PUBLISHRANK_SEO_URL', plugin_dir_url( __FILE__ ) );

// Core services every module relies on: the capability registry, versioned custom tables and
// Access Shield (private login address, brute-force protection, 2FA, CAPTCHA, hardening).
// Booted first on plugins_loaded so later modules can rely on them.
add_action(
	'plugins_loaded',
	static function () {
		\PublishRankSEO\Core\Capabilities::register();
		\PublishRankSEO\Core\Database::register();
		\PublishRankSEO\AccessShield\AccessShield::boot();
		\PublishRankSEO\AI\AiVisibility::boot();
	},
	1
);

// Built-in PublishRank Newsroom editorial workflow module.
require_once __DIR__ . '/src/Newsroom/advanced.php';
require_once __DIR__ . '/src/Newsroom/Newsroom.php';

if ( file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
	require_once __DIR__ . '/vendor/autoload.php';
}

spl_autoload_register(
	static function ( $class ) {
		$prefix = 'PublishRankSEO\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		// Keep autoloading O(1): resolve the expected class path directly. Never
		// recursively scan/read every source file during a live request.
		$file = __DIR__ . '/src/' . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

// One query for every small PublishRank setting instead of one query per setting (no-op with a persistent object cache).
\PublishRankSEO\Core\OptionPreloader::boot();

// Theme masking fast path: neutral asset URLs are answered here, before the theme and the remaining plugins
// load, so masking adds almost nothing to server load. Costs one autoloaded option lookup on other requests.
if ( isset( $_SERVER['REQUEST_URI'] ) && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
	$publishrank_mask_route = get_option( 'publishrank_mask_route' );
	if ( is_array( $publishrank_mask_route ) && ! empty( $publishrank_mask_route['on'] ) && ! empty( $publishrank_mask_route['prefix'] ) ) {
		$publishrank_mask_path = (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- compared, never output.
		if ( 0 === strpos( $publishrank_mask_path, (string) $publishrank_mask_route['prefix'] ) ) {
			$publishrank_mask_cfg = get_option( 'publishrank_mask_config' );
			if ( is_array( $publishrank_mask_cfg ) && ! empty( $publishrank_mask_cfg['enabled'] ) && \PublishRankSEO\Compatibility\Masking\Config::signature() === ( isset( $publishrank_mask_route['sig'] ) ? $publishrank_mask_route['sig'] : '' ) ) {
				\PublishRankSEO\Compatibility\Masking\AssetServer::serve( substr( $publishrank_mask_path, strlen( (string) $publishrank_mask_route['prefix'] ) ), $publishrank_mask_cfg );
			}
		}
	}
	unset( $publishrank_mask_route, $publishrank_mask_path, $publishrank_mask_cfg );
}

/**
 * Template tag for themes that want to place the PublishRank breadcrumb trail themselves:
 * <?php if ( function_exists( 'publishrank_breadcrumbs' ) ) { publishrank_breadcrumbs(); } ?>
 *
 * @param bool $echo Print (true) or return (false) the markup.
 * @return string
 */
if ( ! function_exists( 'publishrank_breadcrumbs' ) ) {
	function publishrank_breadcrumbs( $echo = true ) {
		if ( ! class_exists( '\\PublishRankSEO\\SEO\\BreadcrumbEngine' ) ) {
			return '';
		}
		$html = ( new \PublishRankSEO\SEO\BreadcrumbEngine() )->render();
		if ( $echo ) {
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped while building the markup.
			return '';
		}
		return $html;
	}
}

if ( defined( 'WP_CLI' ) && WP_CLI && is_readable( __DIR__ . '/src/CLI/PublishRankCommand.php' ) ) {
	require_once __DIR__ . '/src/CLI/PublishRankCommand.php';
	add_action(
		'plugins_loaded',
		static function () {
			foreach ( glob( __DIR__ . '/src/CLI/*Command.php' ) as $publishrank_cli ) {
				require_once $publishrank_cli;
			}
		},
		20
	);
}

register_activation_hook(
	__FILE__,
	static function () {
		if ( class_exists( '\\PublishRankSEO\\Core\\Installer' ) ) {
			\PublishRankSEO\Core\Installer::activate();
		}
		if ( class_exists( '\\PublishRankSEO\\Indexing\\IndexNow' ) ) {
			\PublishRankSEO\Indexing\IndexNow::activate();
		}
		if ( class_exists( 'PublishRank_Newsroom' ) ) {
			PublishRank_Newsroom::activate();
		}
		// Redirect an activating administrator to the first-run setup wizard.
		set_transient( 'publishrank_seo_activation_redirect', 1, 120 );
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		if ( class_exists( '\\PublishRankSEO\\Sitemap\\Engine\\SitemapCursorStore' ) ) {
			\PublishRankSEO\Sitemap\Engine\SitemapCursorStore::unregister();
		}
		if ( class_exists( 'PublishRank_Newsroom' ) ) {
			PublishRank_Newsroom::deactivate();
		}
		if ( class_exists( '\\PublishRankSEO\\Monitor\\ScheduledAudit' ) ) {
			\PublishRankSEO\Monitor\ScheduledAudit::clear_schedule();
		}
			foreach ( array( 'publishrank_websub_ping', 'uj_newsroom_purge_trash', 'publishrank_404_retention', 'publishrank_shield_daily', 'publishrank_ai_log_retention', 'publishrank_ai_refresh_ip_lists', 'publishrank_ai_rdns_batch', 'publishrank_ai_citation_batch', 'publishrank_ai_citation_schedule' ) as $publishrank_cron_hook ) {
				wp_clear_scheduled_hook( $publishrank_cron_hook );
			}
			wp_clear_scheduled_hook( 'publishrank_daily_analytics_snapshot' );
			wp_clear_scheduled_hook( 'publishrank_news_refresh' );
			wp_clear_scheduled_hook( 'publishrank_link_check_cron' );
			wp_clear_scheduled_hook( 'publishrank_link_check_batch' );
			flush_rewrite_rules( true );
	}
);


/** Add PublishRank branding and shortcuts to the WordPress toolbar. */
function publishrank_seo_admin_toolbar( $wp_admin_bar ) {
	if ( ! \PublishRankSEO\Core\Capabilities::can( 'view_reports' ) || ! is_object( $wp_admin_bar ) ) {
		return;
	}

	$icon_url  = add_query_arg( 'ver', PUBLISHRANK_SEO_VERSION, plugins_url( 'assets/images/publishrank-brand-mark.png', __FILE__ ) );
	$icon      = '<img class="publishrank-toolbar-icon" src="' . esc_url( $icon_url ) . '" alt="" width="18" height="18" /><span class="ab-label">' . esc_html__( 'PublishRank', 'publishrank' ) . '</span>';
	$dashboard = admin_url( 'admin.php?page=publishrank-seo-dashboard' );
	$settings  = admin_url( 'admin.php?page=publishrank' );

	// Add a branded entry to the top-left WordPress logo dropdown.
	$wp_admin_bar->add_node(
		array(
			'id'     => 'publishrank-wp-logo',
			'parent' => 'wp-logo',
			'title'  => esc_html__( 'PublishRank', 'publishrank' ),
			'href'   => $dashboard,
			'meta'   => array( 'class' => 'publishrank-wp-logo-item' ),
		)
	);

	// Add PublishRank to the horizontal admin toolbar with useful shortcuts.
	$wp_admin_bar->add_node(
		array(
			'id'    => 'publishrank-seo-toolbar',
			'title' => $icon,
			'href'  => $dashboard,
			'meta'  => array(
				'class' => 'publishrank-toolbar-root',
				'title' => esc_attr__( 'PublishRank shortcuts', 'publishrank' ),
			),
		)
	);
		// Keep the toolbar focused; the grouped dashboard submenu exposes every tool.
		$items = array(
			'dashboard' => array( __( 'Dashboard', 'publishrank' ), $dashboard ),
			'newsroom'  => array( __( 'Newsroom', 'publishrank' ), admin_url( 'admin.php?page=uj-newsroom' ) ),
			'titles'    => array( __( 'Titles & Meta', 'publishrank' ), $settings . '#pr-settings-titles' ),
			'settings'  => array( __( 'Settings', 'publishrank' ), $settings ),
			'setup'     => array( __( 'Setup Wizard', 'publishrank' ), admin_url( 'admin.php?page=publishrank-onboarding' ) ),
			'help'      => array( __( 'Documentation & Help', 'publishrank' ), admin_url( 'admin.php?page=publishrank-documentation' ) ),
		);
		$items = apply_filters( 'publishrank_seo_admin_toolbar_items', $items );
		foreach ( (array) $items as $key => $item ) {
			if ( ! is_array( $item ) || ! isset( $item[0], $item[1] ) || ! is_scalar( $item[0] ) || ! is_string( $item[1] ) ) {
				continue;
			}
			$wp_admin_bar->add_node(
				array(
					'id'     => 'publishrank-toolbar-' . $key,
					'parent' => 'publishrank-seo-toolbar',
					'title'  => esc_html( $item[0] ),
					'href'   => esc_url( $item[1] ),
				)
			);
		}
}
add_action( 'admin_bar_menu', 'publishrank_seo_admin_toolbar', 100 );

/** Enqueue the local stylesheet needed to align the admin toolbar shortcut. */
function publishrank_seo_admin_toolbar_styles() {
	if ( ! is_admin_bar_showing() || ! \PublishRankSEO\Core\Capabilities::can( 'view_reports' ) ) {
		return;
	}
	wp_enqueue_style(
		'publishrank-seo-admin-toolbar',
		plugins_url( 'assets/css/admin-toolbar.css', __FILE__ ),
		array(),
		PUBLISHRANK_SEO_VERSION . '.' . (int) @filemtime( __DIR__ . '/assets/css/admin-toolbar.css' )
	);
}
add_action( 'admin_enqueue_scripts', 'publishrank_seo_admin_toolbar_styles' );
add_action( 'wp_enqueue_scripts', 'publishrank_seo_admin_toolbar_styles' );

/** Add useful shortcuts to the Installed Plugins screen (including Multisite). */
function publishrank_seo_plugin_action_links( $links ) {
	$settings    = '<a href="' . esc_url( admin_url( 'admin.php?page=publishrank' ) ) . '">' . esc_html__( 'Settings', 'publishrank' ) . '</a>';
	$wizard      = '<a href="' . esc_url( admin_url( 'admin.php?page=publishrank-onboarding' ) ) . '">' . esc_html__( 'Setup Wizard', 'publishrank' ) . '</a>';
	$sitemap     = '<a href="' . esc_url( admin_url( 'admin.php?page=publishrank-sitemap-health' ) ) . '">' . esc_html__( 'Sitemap Hub', 'publishrank' ) . '</a>';
	$diagnostics = '<a href="' . esc_url( admin_url( 'admin.php?page=publishrank-seo-diagnostics' ) ) . '">' . esc_html__( 'Diagnostics', 'publishrank' ) . '</a>';
	$support     = '<a href="https://publishrankseo.vercel.app/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Official Website', 'publishrank' ) . '</a>';
	return array_merge( array( $settings, $wizard, $sitemap, $diagnostics, $support ), $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'publishrank_seo_plugin_action_links' );
add_filter( 'network_admin_plugin_action_links_' . plugin_basename( __FILE__ ), 'publishrank_seo_plugin_action_links' );

/** Add a "Rate on WordPress.org" link to the plugin's row on the Installed Plugins screen. */
function publishrank_seo_plugin_row_meta( $links, $file ) {
	if ( plugin_basename( __FILE__ ) !== $file ) {
		return $links;
	}
	$links[] = '<a href="' . esc_url( \PublishRankSEO\Core\Branding::rate_url() ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr__( 'Rate PublishRank on WordPress.org', 'publishrank' ) . '">' . esc_html__( '★★★★★ Rate on WordPress.org', 'publishrank' ) . '</a>';
	return $links;
}
add_filter( 'plugin_row_meta', 'publishrank_seo_plugin_row_meta', 10, 2 );

add_action(
	'plugins_loaded',
	static function () {
		if ( class_exists( '\\PublishRankSEO\\Core\\Plugin' ) ) {
			( new \PublishRankSEO\Core\Plugin() )->boot();
		}
	}
);
