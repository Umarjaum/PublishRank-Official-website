<?php
/**
 * Redirect rules facade. Since 2.23 the rules live in the indexed table managed by
 * RedirectRepository; this class keeps the older array-shaped API for the rest of the plugin.
 */
namespace PublishRankSEO\Redirect;

defined( 'ABSPATH' ) || exit;

final class RedirectStore {
	const OPTION    = 'publishrank_seo_redirects';
	const MAX_RULES = 100000;

	/** @return int[] */
	public static function statuses() {
		return array( 301, 302, 303, 307, 308, 410, 451 );
	}

	/** Whether the table-backed engine is in use (always after the 2.23 migration). */
	public static function v2() {
		return RedirectRepository::ready() && get_option( RedirectRepository::MIGRATED_OPT );
	}

	/** Legacy array shape for a repository row. */
	public static function legacy_shape( array $r ) {
		return array(
			'id'             => (int) $r['id'],
			'source'         => $r['source'],
			'target'         => $r['target'],
			'status'         => (int) $r['status'],
			'regex'          => 'regex' === $r['match_type'] ? 1 : 0,
			'match_type'     => $r['match_type'],
			'enabled'        => (int) $r['enabled'],
			'preserve_query' => 'ignore' === $r['flags']['query'] ? 0 : 1,
			'note'           => $r['note'],
			'start_at'       => (int) $r['start_at'],
			'end_at'         => (int) $r['end_at'],
			'hits'           => (int) $r['hits'],
		);
	}

	/**
	 * Rules in the legacy array shape (bounded; use RedirectRepository::query() for paging).
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function all() {
		if ( self::v2() ) {
			$limit = (int) apply_filters( 'publishrank_redirects_all_limit', 20000 );
			return array_map( array( __CLASS__, 'legacy_shape' ), RedirectRepository::all( $limit ) );
		}
		$rules = get_option( self::OPTION, array() );
		return is_array( $rules ) ? array_values( array_filter( $rules, 'is_array' ) ) : array();
	}

	/** @param array<int,array<string,mixed>> $rules Rules to store (pre-migration only). */
	public static function save( array $rules ) {
		if ( self::v2() ) {
			return;
		}
		update_option( self::OPTION, array_slice( array_values( $rules ), 0, 2000 ), false );
	}

	/** Stable identifier for a rule. */
	public static function id( array $rule ) {
		return md5( (string) ( isset( $rule['source'] ) ? $rule['source'] : '' ) . '|' . ( empty( $rule['regex'] ) ? '0' : '1' ) );
	}

	/** Same path normalisation as the runtime redirect controller. */
	public static function normalise_path( $value ) {
		$parsed = wp_parse_url( trim( (string) $value ), PHP_URL_PATH );
		return untrailingslashit( '/' . ltrim( (string) $parsed, '/' ) );
	}

	public static function regex_is_valid( $pattern ) {
		$pattern = (string) $pattern;
		$length  = function_exists( 'mb_strlen' ) ? mb_strlen( $pattern ) : strlen( $pattern );
		if ( '' === $pattern || $length > 255 ) {
			return false;
		}
		return false !== @preg_match( self::compile_regex( $pattern ), '' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	}
	/** Add per-pattern PCRE limits so a pathological expression cannot stall a request. */
	public static function compile_regex( $pattern ) {
		$pattern = (string) $pattern;
		if ( 0 !== strpos( $pattern, '~' ) ) {
			$pattern = '~' . str_replace( '~', '\\~', $pattern ) . '~';
		}
		return '~' === substr( $pattern, 0, 1 ) ? '~(*LIMIT_MATCH=10000)(*LIMIT_DEPTH=1000)' . substr( $pattern, 1 ) : $pattern;
	}

	/** Targets must be a path on this site, a URL on this site, or an allow-listed external host. */
	public static function safe_target( $target, $allow_external = false ) {
		$clean = RedirectRepository::check_target( $target, $allow_external );
		return is_wp_error( $clean ) ? '' : $clean;
	}

	/** @return array<string,mixed>|\WP_Error */
	public static function build_rule( $source, $target, $status = 301, $regex = false ) {
		$status = (int) $status;
		if ( ! in_array( $status, self::statuses(), true ) ) {
			$status = 301;
		}
		$source = trim( (string) $source );
		if ( '' === $source ) {
			return new \WP_Error( 'publishrank_redirect_source', __( 'Enter the old URL or path.', 'publishrank' ) );
		}
		if ( $regex ) {
			$length = function_exists( 'mb_strlen' ) ? mb_strlen( $source ) : strlen( $source );
			if ( $length > 255 ) {
				return new \WP_Error( 'publishrank_redirect_regex_length', __( 'Regular expressions must be 255 characters or fewer.', 'publishrank' ) );
			}
			if ( ! self::regex_is_valid( $source ) ) {
				return new \WP_Error( 'publishrank_redirect_regex', __( 'The regular expression is not valid.', 'publishrank' ) );
			}
		} else {
			$source_host = wp_parse_url( $source, PHP_URL_HOST );
			$home_host   = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
			if ( $source_host && ( ! $home_host || strtolower( $source_host ) !== strtolower( $home_host ) ) ) {
				return new \WP_Error( 'publishrank_redirect_source_host', __( 'The old URL must use this site’s host. Enter a path such as /old-page or a full URL on your own domain.', 'publishrank' ) );
			}
			$source = self::normalise_path( $source );
			if ( '' === $source ) {
				return new \WP_Error( 'publishrank_redirect_home', __( 'The homepage cannot be redirected.', 'publishrank' ) );
			}
		}
		if ( in_array( $status, array( 410, 451 ), true ) ) {
			$target = '';
		} else {
			$target = self::safe_target( $target );
			if ( '' === $target ) {
				return new \WP_Error( 'publishrank_redirect_target', __( 'Enter a target on this site: a path such as /new-page or a full URL on your own domain.', 'publishrank' ) );
			}
			if ( ! $regex && self::normalise_path( $target ) === $source ) {
				return new \WP_Error( 'publishrank_redirect_loop', __( 'The target is the same as the source, which would create a redirect loop.', 'publishrank' ) );
			}
		}
		return array(
			'source'         => $source,
			'target'         => $target,
			'status'         => $status,
			'regex'          => $regex ? 1 : 0,
			'enabled'        => 1,
			'preserve_query' => 1,
			'note'           => '',
			'start_at'       => 0,
			'end_at'         => 0,
		);
	}

	/** Convert admin/local timestamps to UTC epoch seconds and validate the window. */
public static function schedule_window( $start_at = 0, $end_at = 0 ) {
$start = self::timestamp( $start_at ); $end = self::timestamp( $end_at );
		if ( ! is_numeric( $start_at ) && '' !== trim( (string) $start_at ) && ! $start ) return new \WP_Error( 'publishrank_redirect_schedule_start', __( 'The start time is not valid.', 'publishrank' ) );
		if ( ! is_numeric( $end_at ) && '' !== trim( (string) $end_at ) && ! $end ) return new \WP_Error( 'publishrank_redirect_schedule_end', __( 'The end time is not valid.', 'publishrank' ) );
if ( $start && $end && $end <= $start ) return new \WP_Error( 'publishrank_redirect_schedule', __( 'The end time must be later than the start time.', 'publishrank' ) );
return array( 'start_at' => $start, 'end_at' => $end );
}
private static function timestamp( $value ) {
if ( is_numeric( $value ) ) return max( 0, (int) $value );
$value = trim( (string) $value ); if ( '' === $value ) return 0;
try { $dt = new \DateTimeImmutable( $value, wp_timezone() ); return $dt->getTimestamp(); } catch ( \Exception $e ) { return 0; }
}
/** A window is inclusive at the start and exclusive after its end. */
public static function is_scheduled_active( array $rule, $now = null ) {
$now = null === $now ? time() : (int) $now; $start = self::timestamp( $rule['start_at'] ?? 0 ); $end = self::timestamp( $rule['end_at'] ?? 0 );
return ( ! $start || $now >= $start ) && ( ! $end || $now < $end );
}
public static function schedule_label( array $rule ) {
$fmt = get_option( 'date_format', 'Y-m-d' ) . ' ' . get_option( 'time_format', 'H:i' ); $out = array();
foreach ( array( 'start_at' => __( 'Starts', 'publishrank' ), 'end_at' => __( 'Ends', 'publishrank' ) ) as $key => $label ) { $t = self::timestamp( $rule[ $key ] ?? 0 ); if ( $t ) $out[] = $label . ': ' . wp_date( $fmt, $t, wp_timezone() ); }
return $out ? implode( ' · ', $out ) : __( 'Always active', 'publishrank' );
}
	/** Add a rule, or replace the rule that has the same source. @return true|\WP_Error */
	public static function add( $source, $target, $status = 301, $regex = false, $start_at = 0, $end_at = 0, array $extra = array() ) {
		if ( self::v2() ) {
			$res = RedirectRepository::save(
				array_merge(
					array(
						'source'     => $source,
						'target'     => $target,
						'status'     => $status,
						'match_type' => $regex ? 'regex' : 'exact',
						'start_at'   => $start_at,
						'end_at'     => $end_at,
					),
					$extra
				)
			);
			return is_wp_error( $res ) ? $res : true;
		}
		$rule = self::build_rule( $source, $target, $status, $regex );
		if ( ! is_wp_error( $rule ) ) {
			$window = self::schedule_window( $start_at, $end_at );
			if ( is_wp_error( $window ) ) {
				return $window;
			}
			$rule['start_at'] = $window['start_at'];
			$rule['end_at']   = $window['end_at'];
		}
		if ( is_wp_error( $rule ) ) {
			return $rule;
		}
		$rules = self::all();
		foreach ( $rules as $index => $existing ) {
			if ( self::id( $existing ) === self::id( $rule ) ) {
				$rules[ $index ] = $rule;
				self::save( $rules );
				return true;
			}
		}
		if ( count( $rules ) >= 2000 ) {
			return new \WP_Error( 'publishrank_redirect_limit', __( 'The redirect limit has been reached. Remove unused rules first.', 'publishrank' ) );
		}
		$rules[] = $rule;
		self::save( $rules );
		return true;
	}

	/** @param int|string $id Numeric rule id (2.23+) or legacy md5 id. @return bool Whether a rule was removed. */
	public static function delete( $id ) {
		if ( self::v2() ) {
			if ( is_numeric( $id ) ) {
				return RedirectRepository::delete( (int) $id );
			}
			foreach ( self::all() as $rule ) {
				if ( self::id( $rule ) === (string) $id ) {
					return RedirectRepository::delete( (int) $rule['id'] );
				}
			}
			return false;
		}
		$rules = self::all();
		$kept  = array();
		foreach ( $rules as $rule ) {
			if ( self::id( $rule ) !== (string) $id ) {
				$kept[] = $rule;
			}
		}
		if ( count( $kept ) === count( $rules ) ) {
			return false;
		}
		self::save( $kept );
		return true;
	}

	/**
	 * Parse "source target [status]" lines. Pure string handling; plain paths only.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function parse_bulk( $text ) {
		$rows = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || '#' === $line[0] ) {
				continue;
			}
			$parts  = preg_split( '/[\s,]+/', $line, -1, PREG_SPLIT_NO_EMPTY );
			$status = 301;
			$target = '';
			if ( 2 === count( $parts ) && in_array( $parts[1], array( '410', '451' ), true ) ) {
				$status = (int) $parts[1];
			} elseif ( count( $parts ) >= 2 ) {
				$target = $parts[1];
				if ( isset( $parts[2] ) && ctype_digit( $parts[2] ) ) {
					$status = (int) $parts[2];
				}
			}
			$rows[] = array(
				'source' => $parts[0],
				'target' => $target,
				'status' => $status,
			);
		}
		return $rows;
	}

	/** Target for a matched rule; regex rules may use $1…$9 for captured groups of the old path. */
	public static function resolve_target( array $rule, $path ) {
		$target = (string) ( $rule['target'] ?? '' );
		if ( ! empty( $rule['regex'] ) && false !== strpos( $target, '$' ) && self::regex_is_valid( (string) $rule['source'] ) ) {
			$out = @preg_replace( self::compile_regex( (string) $rule['source'] ), $target, (string) $path, 1 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( is_string( $out ) && '' !== $out ) {
				// Captures come from the public URL: keep them to safe path characters.
				$target = (string) preg_replace( '#[^A-Za-z0-9/_\-.~%:?=&+]#', '', $out );
			}
		}
		return $target;
	}

	/** Whether a stored rule matches a normalised request path (same logic as the runtime controller). */
	public static function rule_matches( array $rule, $path ) {
		$source = (string) ( $rule['source'] ?? '' );
		if ( ! empty( $rule['regex'] ) ) {
			if ( strlen( (string) $path ) > 2048 || ! self::regex_is_valid( $source ) ) {
				return false;
			}
			return 1 === @preg_match( self::compile_regex( $source ), (string) $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Validated pattern; a failure means "no match".
		}
		return self::normalise_path( $source ) === (string) $path;
	}

	/**
	 * Follow the redirect rules for a path without making a request.
	 *
	 * @return array<int,array{path:string,status:int,target:string,regex:bool,loop:bool}>
	 */
	public static function trace( $url ) {
		$hops  = array();
		$seen  = array();
		$limit = min( 50, max( 1, absint( get_option( 'publishrank_redirect_max_hops', 10 ) ) ) );
		if ( self::v2() ) {
			$path = RedirectRepository::key( $url );
			for ( $i = 0; $i < $limit; $i++ ) {
				$m = RedirectRepository::match( $path, array( 'ignore_conditions' => true ) );
				if ( ! $m ) {
					break;
				}
				$status = (int) $m['rule']['status'];
				$target = $m['target'];
				$loop   = isset( $seen[ $path ] );
				$hops[] = array( 'path' => $path, 'status' => $status, 'target' => $target, 'regex' => 'regex' === $m['rule']['match_type'], 'loop' => $loop, 'rule_id' => (int) $m['rule']['id'], 'match_type' => $m['rule']['match_type'] );
				$seen[ $path ] = true;
				if ( $loop || in_array( $status, array( 410, 451 ), true ) || '' === $target ) {
					break;
				}
				$host = wp_parse_url( $target, PHP_URL_HOST );
				if ( $host && strtolower( (string) $host ) !== RedirectRepository::home_host() ) {
					break;
				}
				$path = RedirectRepository::key( $target );
			}
			return $hops;
		}
		$path = self::normalise_path( $url );
		for ( $i = 0; $i < $limit; $i++ ) {
			$match = null;
			foreach ( self::all() as $rule ) {
				if ( ! empty( $rule['enabled'] ) && self::is_scheduled_active( $rule ) && self::rule_matches( $rule, $path ) ) {
					$match = $rule;
					break;
				}
			}
			if ( ! $match ) {
				break;
			}
			$status = (int) ( $match['status'] ?? 301 );
			$target = self::resolve_target( $match, $path );
			$loop   = isset( $seen[ $path ] );
			$hops[] = array( 'path' => $path, 'status' => $status, 'target' => $target, 'regex' => ! empty( $match['regex'] ), 'loop' => $loop );
			$seen[ $path ] = true;
			if ( $loop || in_array( $status, array( 410, 451 ), true ) || '' === $target ) {
				break;
			}
			$host = wp_parse_url( $target, PHP_URL_HOST );
			if ( $host && strtolower( (string) $host ) !== strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ) ) {
				break;
			}
			$path = self::normalise_path( $target );
		}
		return $hops;
	}

	/**
	 * Read a CSV export (PublishRank, Yoast Premium, Rank Math, Redirection) into rule rows.
	 * Recognised headers: source/from/origin/url, target/to/destination/redirect_to, status/type/code/http_code, regex/format/match_type.
	 *
	 * @return array<int,array{source:string,target:string,status:int,regex:bool}>
	 */
	public static function parse_csv( $csv ) {
		$csv   = (string) preg_replace( '/^\xEF\xBB\xBF/', '', (string) $csv );
		$lines = preg_split( '/\r\n|\r|\n/', $csv );
		$rows  = array();
		$map   = null;
		$alias = array(
			'source' => array( 'source', 'from', 'origin', 'url', 'old', 'source_url', 'sources' ),
			'target' => array( 'target', 'to', 'destination', 'redirect_to', 'new', 'target_url', 'action_data' ),
			'status' => array( 'status', 'type', 'code', 'http_code', 'redirect_type', 'header_code', 'action_code' ),
			'regex'  => array( 'regex', 'format', 'match_type', 'comparison', 'is_regex' ),
		);
		foreach ( $lines as $line ) {
			if ( '' === trim( (string) $line ) ) {
				continue;
			}
			$cells = array_map( 'trim', str_getcsv( (string) $line, ',', '"', '\\' ) );
			if ( null === $map ) {
				$lower = array_map( 'strtolower', $cells );
				$found = array();
				foreach ( $alias as $field => $names ) {
					foreach ( $lower as $i => $h ) {
						if ( in_array( $h, $names, true ) ) {
							$found[ $field ] = $i;
							break;
						}
					}
				}
				if ( isset( $found['source'] ) ) {
					$map = $found;
					continue;
				}
				$map = array( 'source' => 0, 'target' => 1, 'status' => 2, 'regex' => 3 );
			}
			$source = (string) ( $cells[ $map['source'] ] ?? '' );
			if ( '' === $source ) {
				continue;
			}
			$status = isset( $map['status'] ) ? (int) preg_replace( '/\D/', '', (string) ( $cells[ $map['status'] ] ?? '' ) ) : 0;
			$flag   = isset( $map['regex'] ) ? strtolower( (string) ( $cells[ $map['regex'] ] ?? '' ) ) : '';
			$rows[] = array(
				'source' => $source,
				'target' => isset( $map['target'] ) ? (string) ( $cells[ $map['target'] ] ?? '' ) : '',
				'status' => in_array( $status, self::statuses(), true ) ? $status : 301,
				'regex'  => in_array( $flag, array( '1', 'yes', 'true', 'regex' ), true ),
			);
		}
		return $rows;
	}
}
