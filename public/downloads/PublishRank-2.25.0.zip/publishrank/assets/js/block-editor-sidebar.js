/**
 * PublishRank sidebar for the block editor.
 *
 * - A live SEO score badge sits in the editor's top toolbar (the pinned sidebar icon). It recolors and
 *   updates as you write, so the score is always visible without covering the content.
 * - Clicking it opens the PublishRank SEO sidebar: the full SEO Analysis panel is docked at the top,
 *   followed by every SEO field (tabbed: Published values, Search appearance, Social sharing, ...).
 * - The analysis can be popped out into a floating panel and docked back (remembered per browser).
 * - Also reachable from the editor's Options menu and the command palette (Ctrl/Cmd + K).
 * No build step: plain wp.element calls.
 */
(function (wp) {
	if (!wp || !wp.plugins || !wp.element || !wp.data || !wp.components) { return; }
	var el = wp.element.createElement;
	var useState = wp.element.useState, useEffect = wp.element.useEffect;
	var useLayoutEffect = wp.element.useLayoutEffect || wp.element.useEffect, useRef = wp.element.useRef;
	var __ = (wp.i18n && wp.i18n.__) || function (s) { return s; };
	var editorPkg = wp.editor && wp.editor.PluginSidebar ? wp.editor : wp.editPost;
	if (!editorPkg || !editorPkg.PluginSidebar) { return; }
	var PluginSidebar = editorPkg.PluginSidebar;
	var PluginSidebarMoreMenuItem = editorPkg.PluginSidebarMoreMenuItem;
	var C = wp.components;
	var PLUGIN = 'publishrank-seo', SIDEBAR = 'publishrank-seo-sidebar', FULL = PLUGIN + '/' + SIDEBAR;
	var SEEN = 'publishrank-seo-sidebar-introduced';

	function card() { return window.PublishRankScoreCard || null; }
	function band(n) { return n >= 90 ? 'excellent' : (n >= 80 ? 'good' : (n >= 55 ? 'ok' : 'bad')); }

	function openSidebar() {
		try { var ep = wp.data.dispatch('core/edit-post'); if (ep && ep.openGeneralSidebar) { ep.openGeneralSidebar(FULL); return; } } catch (e) {}
		try { wp.data.dispatch('core/interface').enableComplementaryArea('core', FULL); } catch (e) {}
	}

	function useScore() {
		var initial = card() ? card().score() : { score: 0, band: 'bad', label: '' };
		var st = useState(initial);
		useEffect(function () {
			function on(e) { if (e && e.detail) { st[1](e.detail); } }
			document.addEventListener('publishrank:score', on);
			if (card()) { st[1](card().score()); }
			return function () { document.removeEventListener('publishrank:score', on); };
		}, []);
		return st[0];
	}
	function useMode() {
		var st = useState(card() ? card().mode() : 'docked');
		useEffect(function () {
			function on(e) { if (e && e.detail) { st[1](e.detail.mode); } }
			document.addEventListener('publishrank:mode', on);
			return function () { document.removeEventListener('publishrank:mode', on); };
		}, []);
		return st[0];
	}

	/* Live score ring used as the toolbar icon. */
	function Badge() {
		var s = useScore(), n = Math.max(0, Math.min(100, parseInt(s.score, 10) || 0));
		return el('span', { className: 'pr-esc-badge is-' + (s.band || band(n)), style: { '--pr-esc-score': String(n) }, 'aria-hidden': 'true' },
			el('b', null, String(n)));
	}

	function seoWindow() { return window.PublishRankSeoWindow || null; }
	/* True while the movable SEO editor window holds the fields, previews and analysis. */
	function useWindowOpen() {
		var st = useState(seoWindow() ? seoWindow().isOpen() : false);
		useEffect(function () {
			function on(e) { st[1](!!(e && e.detail && e.detail.open)); }
			document.addEventListener('publishrank:seowin', on);
			return function () { document.removeEventListener('publishrank:seowin', on); };
		}, []);
		return st[0];
	}
	function WindowLauncher() {
		var open = useWindowOpen();
		if (!seoWindow()) { return null; }
		if (open) {
			return el('div', { className: 'pr-esc-dock-note pr-seowin-note' },
				el('p', null, __('The SEO editor is open as a movable window. Drag its header to move it anywhere.', 'publishrank')),
				el(C.Button, { variant: 'secondary', onClick: function () { seoWindow().close(); } }, __('Dock it back here', 'publishrank')));
		}
		return el(C.Button, { variant: 'primary', icon: 'external', className: 'pr-seowin-launch', onClick: function () { seoWindow().open(); } }, __('Open movable SEO editor', 'publishrank'));
	}

	/* The PHP-rendered SEO Analysis panel is moved into this slot while the sidebar is open. */
	function AnalysisDock() {
		var ref = useRef(null), mode = useMode(), winOpen = useWindowOpen();
		useLayoutEffect(function () {
			var api = card(), slot = ref.current;
			if (!api || !slot || mode !== 'docked' || winOpen) { return; }
			api.dock(slot);
			return function () { api.release(slot); };
		}, [mode, winOpen]);
		if (winOpen) { return null; }
		if (!card()) {
			return el('p', { className: 'pr-esc-dock-note' }, __('The SEO analysis is not available for this post type.', 'publishrank'));
		}
		if (mode === 'floating') {
			return el('div', { className: 'pr-esc-dock-note' },
				el('p', null, __('The SEO analysis is popped out as a floating panel.', 'publishrank')),
				el(C.Button, { variant: 'secondary', onClick: function () { card().setMode('docked'); } }, __('Dock it here', 'publishrank')));
		}
		return el('div', { ref: ref, className: 'pr-esc-dock pr-esc-dock--sidebar' });
	}

	/* The SEO fields (Published values, Search appearance, Social sharing, ...) are docked here while the
	 * sidebar is open, and handed back to the bottom Meta Boxes area when it closes (see seo-dock.js). */
	function FieldsDock() {
		var ref = useRef(null), st = useState(false), docked = st[0], setDocked = st[1], winOpen = useWindowOpen();
		useLayoutEffect(function () {
			var slot = ref.current, timer = 0, tries = 0;
			if (!slot || winOpen) { setDocked(false); return; }
			function attempt() {
				var api = window.PublishRankSeoDock;
				if (api && api.dock(slot)) { setDocked(true); return true; }
				return false;
			}
			if (!attempt()) {
				timer = window.setInterval(function () { if (attempt() || ++tries > 30) { window.clearInterval(timer); timer = 0; } }, 300);
			}
			return function () {
				if (timer) { window.clearInterval(timer); }
				if (window.PublishRankSeoDock) { window.PublishRankSeoDock.release(slot); }
			};
		}, [winOpen]);
		if (winOpen) { return el('div', { ref: ref, hidden: true }); }
		return el('div', { className: 'pr-seodock-slot' },
			el('h2', { className: 'pr-seodock-slot__head' }, __('SEO fields', 'publishrank')),
			docked ? null : el('p', { className: 'pr-seodock-slot__note' }, __('Loading the SEO fields…', 'publishrank')),
			el('div', { ref: ref }));
	}

	function Commands() {
		wp.commands.useCommand({
			name: 'publishrank/open-seo-analysis',
			label: __('Open PublishRank SEO analysis', 'publishrank'),
			callback: function (o) { openSidebar(); if (o && o.close) { o.close(); } }
		});
		wp.commands.useCommand({
			name: 'publishrank/toggle-seo-window',
			label: __('Open or close the movable PublishRank SEO editor', 'publishrank'),
			callback: function (o) { if (seoWindow()) { seoWindow().toggle(); } if (o && o.close) { o.close(); } }
		});
		return null;
	}

	/* Always mounted: listens for "dock" requests from the floating panel and introduces the sidebar once. */
	function Bridge() {
		useEffect(function () {
			function on() { openSidebar(); }
			document.addEventListener('publishrank:open-sidebar', on);
			var seen = true; try { seen = window.localStorage.getItem(SEEN) === '1'; } catch (e) {}
			if (!seen && window.innerWidth > 782 && card() && card().mode() === 'docked') {
				window.setTimeout(openSidebar, 300);
				try { window.localStorage.setItem(SEEN, '1'); } catch (e) {}
			}
			return function () { document.removeEventListener('publishrank:open-sidebar', on); };
		}, []);
		return null;
	}

	wp.plugins.registerPlugin(PLUGIN, {
		icon: 'chart-line',
		render: function () {
			return el(wp.element.Fragment, null,
				el(Bridge),
				wp.commands && wp.commands.useCommand ? el(Commands) : null,
				PluginSidebarMoreMenuItem ? el(PluginSidebarMoreMenuItem, { target: SIDEBAR, icon: 'chart-line' }, 'PublishRank SEO') : null,
				el(PluginSidebar, { name: SIDEBAR, title: 'PublishRank SEO', icon: el(Badge), className: 'pr-esc-sidebar' },
					el(WindowLauncher),
					el(AnalysisDock),
					el(FieldsDock))
			);
		}
	});
})(window.wp);
