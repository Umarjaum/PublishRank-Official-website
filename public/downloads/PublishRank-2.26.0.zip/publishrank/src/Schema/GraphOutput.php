<?php
/** Emits one connected JSON-LD graph for the current document. */
// Primary article output is restricted to the centrally registered article family; other selections use their own builders.
namespace PublishRankSEO\Schema;

use PublishRankSEO\Core\OutputRegistry;
use PublishRankSEO\Core\OutputSettings;
use PublishRankSEO\Core\PublicationProfile;
use PublishRankSEO\Meta\PostMeta;
use PublishRankSEO\SEO\BreadcrumbEngine;
use PublishRankSEO\SEO\NewsroomSignals;

defined( 'ABSPATH' ) || exit;

final class GraphOutput {
	/** @var OutputRegistry */
	private $registry;

	public function __construct( OutputRegistry $registry ) {
		$this->registry = $registry; }
	public function register() {
		add_action( 'wp_head', array( $this, 'render' ), 20 ); }

	/**
	 * Fail-safe entry point: a problem while building this output can never take the public page down.
	 * Partial markup is discarded and the failure is recorded for the integrity/diagnostics screens.
	 */
	public function render() {
		ob_start();
		try {
			$this->render_output();
			echo ob_get_clean(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup was escaped where it was built.
		} catch ( \Throwable $e ) {
			ob_end_clean();
			do_action( 'publishrank_module_failed', __CLASS__, 'runtime_exception', false, $e->getMessage() );
			// Never fail silently: leave a visible hint in the page source so a missing graph can be diagnosed.
			echo '<!-- PublishRank structured data skipped: ' . esc_html( str_replace( '--', '- -', substr( $e->getMessage(), 0, 160 ) ) ) . " -->\n";
		}
	}

	/** Render one connected graph when PublishRank owns the JSON-LD slot. */
	private function render_output() {
		if ( is_admin() || wp_doing_ajax() || ! OutputSettings::schema_graph_output() || ! $this->registry->claim( 'jsonld', 'graph-output' ) ) {
			return; }
		$identity = $this->identity_entity();
		$graph    = array( $identity, $this->website(), $this->webpage() );
		$list     = null;
		if ( $this->is_editorial_article() ) {
			$graph[] = $this->article();
			$graph[] = $this->article_author();
		}
		if ( ! is_singular() && ! is_404() ) {
			$list = $this->collection_list();
			if ( $list ) {
				$graph[] = $list;
				// An author's ProfilePage is about the Person; every other listing is about its item list.
				if ( ! is_author() || 'ProfilePage' !== ( $graph[2]['@type'] ?? '' ) ) {
					$graph[2]['mainEntity'] = array( '@id' => trailingslashit( ( new \PublishRankSEO\Meta\MetaGenerator() )->canonical() ) . '#itemlist' );
				}
			}
		}
		if ( $this->is_editorial_article() ) {
			$claim = $this->claim_review( get_queried_object() );
			if ( $claim ) {
				$graph[] = $claim; }
		}
		$graph = apply_filters( 'publishrank_schema_graph', $graph, $this );
		if ( ! is_array( $graph ) ) {
			$graph = array(); }
		$graph = array_values( array_filter( $graph, 'is_array' ) );
		$crumbs_emitted = false;
		if ( BreadcrumbEngine::schema_enabled() && BreadcrumbEngine::context_supported() && '' === BreadcrumbEngine::external_schema_owner() ) {
			// The BreadcrumbList is built from the same items as the visible trail. A list with fewer than
			// two real items is not useful (or valid) markup, so it is only emitted when there is a trail.
			$crumbs = ( new BreadcrumbEngine() )->schema();
			if ( ! empty( $crumbs['itemListElement'] ) && count( $crumbs['itemListElement'] ) >= 2 ) {
				$graph[]        = $crumbs;
				$crumbs_emitted = true;
				foreach ( $graph as $graph_index => $graph_node ) {
					if ( isset( $graph_node['@id'] ) && '#webpage' === substr( (string) $graph_node['@id'], -8 ) ) {
						$graph[ $graph_index ]['breadcrumb'] = array( '@id' => $crumbs['@id'] );
						break;
					}
				}
			}
		}
		if ( ! $crumbs_emitted ) {
			// Never reference a BreadcrumbList that is not output (switched off, no trail, or owned by another plugin).
			foreach ( $graph as $graph_index => $graph_node ) {
				if ( isset( $graph_node['@id'], $graph_node['breadcrumb'] ) && '#webpage' === substr( (string) $graph_node['@id'], -8 ) ) {
					unset( $graph[ $graph_index ]['breadcrumb'] );
				}
			}
		}
		foreach ( ( new SchemaBuilder() )->extra_nodes() as $node ) {
			$graph[] = $node; }
		/**
		 * Final graph, after every PublishRank node is present and before de-duplication. Schema Studio
		 * merges its templates here so it can enrich existing nodes instead of printing duplicates.
		 */
		$final = apply_filters( 'publishrank_schema_graph_final', $graph, $this );
		$graph = is_array( $final ) ? array_values( array_filter( $final, 'is_array' ) ) : $graph;
		$graph = self::dedupe_graph( $graph );
		// Never print empty top-level values such as "description": "" (search and archive pages without text).
		foreach ( $graph as $gi => $gnode ) {
			foreach ( $gnode as $gk => $gv ) {
				if ( is_string( $gk ) && '@' !== $gk[0] && ( '' === $gv || array() === $gv || null === $gv ) ) {
					unset( $graph[ $gi ][ $gk ] );
				}
			}
		}
		// "Organization and website schema" is a separate switch: the identity and WebSite nodes are removed here, after
		// every filter and extra node has been merged, together with any reference that would otherwise point at them.
		$identity_on = OutputSettings::org_website_schema() && PublicationProfile::identity_schema_ready();
		if ( ! $identity_on ) {
			$graph = self::without_identity_nodes( $graph );
		}
		// Every { "@id": ... } reference must resolve inside the graph, so a node that is only defined nested (such as the publisher logo) is also listed as its own entry.
		$graph = self::hoist_embedded_references( $graph );
		if ( empty( $graph ) ) {
			return; }
		$entities = $identity_on ? ( PublicationProfile::identity_is_person() ? 'person,website,webpage' : 'organization,website,webpage' ) : 'webpage';
		if ( $this->is_editorial_article() ) {
			$entities .= ',article'; }
		if ( $list ) {
			$entities .= ',itemlist'; }
		$markers = OutputSettings::source_markers();
		echo ( $markers ? '<!-- SEO Powered by PublishRank: structured data begin; entities=' : '<!-- PublishRank: begin; structured data; entities=' ) . esc_attr( $entities ) . " -->\n";
		echo '<script type="application/ld+json">';
		echo wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $graph,
			),
			JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
		);
		echo '</script>' . "\n";
		echo $markers ? "<!-- end of SEO data Powered by PublishRank -->\n" : "<!-- PublishRank: end -->\n";
	}

	/**
	 * Remove the Organization/Person and WebSite nodes of the primary identity and every { "@id": ... } reference to them.
	 * Other nodes (WebPage, Article, BreadcrumbList ...) stay valid because optional links are simply dropped.
	 *
	 * @param array<int,array<string,mixed>> $graph Graph nodes.
	 * @return array<int,array<string,mixed>>
	 */
	public static function without_identity_nodes( array $graph ) {
		$base    = trailingslashit( PublicationProfile::primary_url() );
		$removed = array( $base . '#organization', $base . '#person', $base . '#website' );
		$kept    = array();
		foreach ( $graph as $node ) {
			if ( is_array( $node ) && isset( $node['@id'] ) && in_array( (string) $node['@id'], $removed, true ) ) {
				continue; }
			$kept[] = self::strip_references( $node, $removed );
		}
		return $kept;
	}

	/**
	 * Add a top-level node for every { "@id": ... } reference whose target is only defined nested inside another node.
	 * Nothing is removed or rewritten: references to ids that are not defined anywhere (for example another page) are left alone.
	 *
	 * @param array<int,array<string,mixed>> $graph Graph nodes.
	 * @return array<int,array<string,mixed>>
	 */
	public static function hoist_embedded_references( array $graph ) {
		$defined  = array();
		$refs     = array();
		$embedded = array();
		foreach ( $graph as $node ) {
			if ( is_array( $node ) && isset( $node['@id'] ) ) {
				$defined[ (string) $node['@id'] ] = true; }
		}
		$walk = null;
		$walk = static function ( $value, $top ) use ( &$walk, &$refs, &$embedded ) {
			if ( ! is_array( $value ) ) {
				return; }
			if ( ! $top && isset( $value['@id'] ) && is_scalar( $value['@id'] ) ) {
				$id = (string) $value['@id'];
				if ( 1 === count( $value ) ) {
					$refs[ $id ] = true;
				} elseif ( isset( $value['@type'] ) && ! isset( $embedded[ $id ] ) ) {
					$embedded[ $id ] = $value; }
			}
			foreach ( $value as $child ) {
				$walk( $child, false ); }
		};
		foreach ( $graph as $node ) {
			$walk( $node, true ); }
		foreach ( array_keys( $refs ) as $id ) {
			if ( ! isset( $defined[ $id ] ) && isset( $embedded[ $id ] ) ) {
				$graph[]       = $embedded[ $id ];
				$defined[ $id ] = true; }
		}
		return $graph;
	}

	/** @param mixed $value Node or property value. @param string[] $ids Ids to drop. @return mixed */
	private static function strip_references( $value, array $ids ) {
		if ( ! is_array( $value ) ) {
			return $value; }
		$is_list = array_keys( $value ) === range( 0, count( $value ) - 1 );
		$out     = array();
		foreach ( $value as $key => $child ) {
			if ( is_array( $child ) && 1 === count( $child ) && isset( $child['@id'] ) && in_array( (string) $child['@id'], $ids, true ) ) {
				continue; // A pure reference to a removed node.
			}
			$child = self::strip_references( $child, $ids );
			if ( $is_list ) {
				$out[] = $child; } else {
				$out[ $key ] = $child; }
		}
		return $out;
	}

	/** @return array<string, mixed> */
	private function identity_entity() {
		return PublicationProfile::identity_is_person() ? $this->person() : $this->organization();
	}
	/** @return array<string, mixed> */
	/** @return array<string, mixed> */
	private function organization() {
		$url  = trailingslashit( PublicationProfile::primary_url() );
		$org  = PublicationProfile::organization_identity();
		$type = sanitize_text_field( (string) get_option( 'publishrank_seo_publisher_type', 'NewsMediaOrganization' ) );
		$type = in_array( $type, array( 'NewsMediaOrganization', 'Organization' ), true ) ? $type : 'NewsMediaOrganization';

		$logo_url = $org['logo'] ? esc_url_raw( $org['logo'] ) : '';
		if ( ! $logo_url ) {
			$theme_logo = get_theme_mod( 'custom_logo' );
			$logo_url   = $theme_logo ? wp_get_attachment_image_url( (int) $theme_logo, 'full' ) : '';
		}
		if ( ! $logo_url && function_exists( 'get_site_icon_url' ) ) {
			$logo_url = get_site_icon_url( 512 ); }
		$country      = strtoupper( sanitize_text_field( $org['country'] ) );
		$organization = array(
			'@type' => $type,
			'@id'   => $url . '#organization',
			'name'  => $org['name'] ? sanitize_text_field( $org['name'] ) : PublicationProfile::publisher_name(),
			'url'   => $url,
		);
		if ( $org['legal_name'] ) {
			$organization['legalName'] = sanitize_text_field( $org['legal_name'] ); }
		if ( ! empty( $org['alternate_names'] ) ) {
			$organization['alternateName'] = $org['alternate_names'];
		} elseif ( $org['alternate_name'] ) {
			$organization['alternateName'] = sanitize_text_field( $org['alternate_name'] ); }
		if ( $org['description'] ) {
			$organization['description'] = wp_strip_all_tags( $org['description'] ); }
		if ( $org['founding_date'] && preg_match( '/^\d{4}(?:-\d{2}(?:-\d{2})?)?$/', $org['founding_date'] ) ) {
			$organization['foundingDate'] = $org['founding_date'];
		}
		if ( $org['contact_email'] || $org['contact_phone'] ) {
			$organization['contactPoint'] = array(
				'@type'       => 'ContactPoint',
				'contactType' => 'customer support',
			);
			if ( $org['contact_email'] ) {
				$organization['contactPoint']['email'] = sanitize_email( $org['contact_email'] ); }
			if ( $org['contact_phone'] ) {
				$organization['contactPoint']['telephone'] = sanitize_text_field( $org['contact_phone'] ); }
		}
		if ( $org['street'] || $org['locality'] || $org['region'] || $org['postal_code'] || $country ) {
			$organization['address'] = array( '@type' => 'PostalAddress' );
			if ( $org['street'] ) {
				$organization['address']['streetAddress'] = sanitize_text_field( $org['street'] ); }
			if ( $org['locality'] ) {
				$organization['address']['addressLocality'] = sanitize_text_field( $org['locality'] ); }
			if ( $org['region'] ) {
				$organization['address']['addressRegion'] = sanitize_text_field( $org['region'] ); }
			if ( $org['postal_code'] ) {
				$organization['address']['postalCode'] = sanitize_text_field( $org['postal_code'] ); }
			if ( $country ) {
				$organization['address']['addressCountry'] = $country; }
		}
		if ( $country ) {
			$organization['areaServed'] = array(
				'@type' => 'Country',
				'name'  => $country,
			); }
		if ( $logo_url ) {
			$organization['logo'] = $this->image_object( $logo_url, $url . '#publisher-logo' ); }
		if ( ! empty( $org['parent_organization'] ) ) {
			$organization['parentOrganization'] = array(
				'@type' => 'Organization',
				'name'  => sanitize_text_field( $org['parent_organization'] ),
			); }
		if ( ! empty( $org['owner_name'] ) ) {
			$owner = array(
				'@type' => 'Organization',
				'name'  => sanitize_text_field( $org['owner_name'] ),
			);
			if ( ! empty( $org['owner_url'] ) ) {
				$owner['url'] = esc_url_raw( $org['owner_url'] );
			} if ( ! empty( $org['owner_logo'] ) ) {
				$owner['logo'] = $this->image_object( $org['owner_logo'], $url . '#owner-logo' );
			} $organization['owner'] = $owner; }
		if ( ! empty( $org['copyright_holder'] ) ) {
			$organization['copyrightHolder'] = array(
				'@type' => 'Organization',
				'name'  => sanitize_text_field( $org['copyright_holder'] ),
			); }
		if ( ! empty( $org['founder'] ) ) {
			$organization['founder'] = array(
				'@type' => 'Person',
				'name'  => sanitize_text_field( $org['founder'] ),
			); }
		if ( ! empty( $org['founding_location'] ) ) {
			$organization['foundingLocation'] = array(
				'@type' => 'Place',
				'name'  => sanitize_text_field( $org['founding_location'] ),
			); }
		if ( ! empty( $org['knows_about'] ) ) {
			$topics = array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/\s*,\s*/', (string) $org['knows_about'] ) ) ) );
			if ( $topics ) {
				$organization['knowsAbout'] = $topics; }
		}
		$social = PublicationProfile::social_profiles();
		if ( ! empty( $social ) ) {
			$organization['sameAs'] = $social; }
		$organization = $this->organization_advanced( $organization, $org, $url, $type, $logo_url );
		return (array) apply_filters( 'publishrank_schema_organization', $organization );
	}

	/**
	 * Google-recommended Organization properties and NewsMediaOrganization trust signals: top-level email
	 * and telephone, several contact points, identifiers (VAT, tax, DUNS, LEI, ISO 6523, NAICS), slogan,
	 * employee count, image, and the editorial policy pages (ethics, corrections, masthead …).
	 *
	 * @param array<string,mixed> $organization Node.
	 * @param array<string,mixed> $org          Stored identity.
	 * @param string              $url          Site URL.
	 * @param string              $type         Organization type.
	 * @param string              $logo_url     Logo URL.
	 * @return array<string,mixed>
	 */
	private function organization_advanced( array $organization, array $org, $url, $type, $logo_url ) {
		if ( ! empty( $org['contact_email'] ) && is_email( $org['contact_email'] ) ) {
			$organization['email'] = sanitize_email( $org['contact_email'] );
		}
		if ( ! empty( $org['contact_phone'] ) ) {
			$organization['telephone'] = sanitize_text_field( $org['contact_phone'] );
		}
		$points = isset( $organization['contactPoint'] ) ? array( $organization['contactPoint'] ) : array();
		foreach ( array(
			'editorial_email'   => 'editorial',
			'advertising_email' => 'advertising',
			'tips_email'        => 'news tips',
		) as $key => $contact_type ) {
			if ( ! empty( $org[ $key ] ) && is_email( $org[ $key ] ) ) {
				$points[] = array(
					'@type'       => 'ContactPoint',
					'contactType' => $contact_type,
					'email'       => sanitize_email( $org[ $key ] ),
				);
			}
		}
		if ( $points ) {
			if ( ! empty( $organization['address']['addressCountry'] ) ) {
				foreach ( $points as $i => $point ) {
					$points[ $i ]['areaServed'] = $organization['address']['addressCountry'];
				}
			}
			$language = sanitize_text_field( (string) get_option( 'publishrank_default_language', substr( (string) get_locale(), 0, 2 ) ) );
			foreach ( $points as $i => $point ) {
				$points[ $i ]['availableLanguage'] = $language;
			}
			$organization['contactPoint'] = 1 === count( $points ) ? $points[0] : $points;
		}
		foreach ( array(
			'vat_id'    => 'vatID',
			'tax_id'    => 'taxID',
			'duns'      => 'duns',
			'lei_code'  => 'leiCode',
			'iso6523'   => 'iso6523Code',
			'naics'     => 'naics',
			'slogan'    => 'slogan',
		) as $key => $prop ) {
			if ( ! empty( $org[ $key ] ) ) {
				$organization[ $prop ] = sanitize_text_field( $org[ $key ] );
			}
		}
		$employees = isset( $org['employees'] ) ? absint( $org['employees'] ) : 0;
		if ( $employees > 0 ) {
			$organization['numberOfEmployees'] = array(
				'@type' => 'QuantitativeValue',
				'value' => $employees,
			);
		}
		if ( $logo_url ) {
			$organization['image'] = array( '@id' => $url . '#publisher-logo' );
		}
		$principles = PublicationProfile::publishing_principles();
		if ( $principles ) {
			if ( ! empty( $principles['publishingPrinciples'] ) ) {
				$organization['publishingPrinciples'] = $principles['publishingPrinciples'];
			}
			if ( 'NewsMediaOrganization' === $type ) {
				foreach ( $principles as $prop => $policy_url ) {
					if ( 'publishingPrinciples' !== $prop ) {
						$organization[ $prop ] = $policy_url;
					}
				}
			}
		}
		return $organization;
	}

	/** Stable @id for the configured publisher identity. */
	private function identity_id() {
		return trailingslashit( PublicationProfile::primary_url() ) . ( PublicationProfile::identity_is_person() ? '#person' : '#organization' ); }

	/** @return array<string, mixed> */
	private function person() {
		$url    = trailingslashit( PublicationProfile::primary_url() );
		$person = PublicationProfile::person_identity();
		$node   = array(
			'@type' => 'Person',
			'@id'   => $url . '#person',
			'name'  => $person['name'] ? sanitize_text_field( $person['name'] ) : PublicationProfile::publisher_name(),
			'url'   => $person['url'] ? esc_url_raw( $person['url'] ) : $url,
		);
		if ( $person['alternate_name'] ) {
			$node['alternateName'] = sanitize_text_field( $person['alternate_name'] ); }
		if ( $person['description'] ) {
			$node['description'] = wp_strip_all_tags( $person['description'] ); }
		if ( $person['job_title'] ) {
			$node['jobTitle'] = sanitize_text_field( $person['job_title'] ); }
		if ( $person['email'] ) {
			$node['email'] = sanitize_email( $person['email'] ); }
		if ( $person['image'] ) {
			$node['image'] = $this->image_object( $person['image'], $url . '#person-image' ); }
		$social = PublicationProfile::social_profiles();
		if ( ! empty( $social ) ) {
			$node['sameAs'] = $social; }
		return $node;
	}
	/** @return array<string, mixed> */
	private function website() {
		$url = trailingslashit( PublicationProfile::primary_url() );
		$alt = PublicationProfile::site_alternate_names();
		$node = array(
			'@type'           => 'WebSite',
			'@id'             => $url . '#website',
			'url'             => $url,
			'name'            => PublicationProfile::site_name(),
			'description'     => wp_strip_all_tags( (string) \PublishRankSEO\Core\PublicationProfile::publication_description() ),
			'publisher'       => array( '@id' => $this->identity_id() ),
			'inLanguage'      => \PublishRankSEO\Meta\LanguageAlternates::current_locale(),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => array(
					'@type'       => 'EntryPoint',
					'urlTemplate' => $url . '?s={search_term_string}',
				),
				'query-input' => 'required name=search_term_string',
			),
		);
		if ( ! empty( $alt ) ) {
			// Place alternateName right after name, as Google's site name documentation shows it.
			$ordered = array();
			foreach ( $node as $key => $value ) {
				$ordered[ $key ] = $value;
				if ( 'name' === $key ) {
					$ordered['alternateName'] = 1 === count( $alt ) ? $alt[0] : $alt; }
			}
			$node = $ordered;
		}
		return $node;
	}

	/** @return array<string, mixed> */
	private function webpage() {
		$canonical = ( new \PublishRankSEO\Meta\MetaGenerator() )->canonical();
		$url       = trailingslashit( $canonical );
		$page      = array(
			'@type'       => ( new SchemaBuilder() )->current_webpage_type(),
			'@id'         => $url . '#webpage',
			'url'         => $canonical,
			'name'        => wp_get_document_title(),
			'description' => ( new \PublishRankSEO\Meta\MetaGenerator() )->description(),
			// A singular page's language follows its content (an Arabic or Urdu post on an English site), matching the Article node.
			'inLanguage'  => is_singular() ? \PublishRankSEO\Meta\LanguageAlternates::content_language( (int) get_queried_object_id() ) : \PublishRankSEO\Meta\LanguageAlternates::current_locale(),
			'isPartOf'    => array( '@id' => trailingslashit( PublicationProfile::primary_url() ) . '#website' ),
			'about'       => array( '@id' => $this->identity_id() ),
		);
		if ( is_author() && 'ProfilePage' === $page['@type'] ) {
			$page['mainEntity'] = array( '@id' => trailingslashit( get_author_posts_url( (int) get_queried_object_id() ) ) . '#author' );
		}
		if ( is_singular() ) {
			$post                  = get_queried_object();
			$page['datePublished'] = get_post_time( DATE_W3C, true, $post );
			$page['dateModified']  = get_post_modified_time( DATE_W3C, true, $post );
			$page['breadcrumb']    = array( '@id' => $url . '#breadcrumb' );
			if ( $this->is_editorial_article() ) {
				$page['mainEntity'] = array( '@id' => $url . '#article' ); }
			if ( 'FAQPage' === $page['@type'] && $post instanceof \WP_Post ) {
				$faq = ( new SchemaBuilder() )->faq_entities( $post );
				if ( $faq ) {
					$page['mainEntity'] = $faq;
				} else {
					$page['@type'] = 'WebPage'; }
			} elseif ( $post instanceof \WP_Post && is_string( $page['@type'] ) && in_array( $page['@type'], array( 'WebPage', 'ItemPage', 'AboutPage', 'ContactPage', 'CollectionPage' ), true ) ) {
				// A visible FAQ block on an ordinary page or article: the page is also an FAQPage. Articles
				// keep their own node (linked through mainEntityOfPage); the questions become the page's
				// main entity, so there is exactly one FAQPage per URL.
				$faq = ( new SchemaBuilder() )->faq_entities( $post );
				if ( $faq ) {
					$page['@type']      = array( $page['@type'], 'FAQPage' );
					$page['mainEntity'] = $faq;
				}
			}
			$found = $post instanceof \WP_Post ? \PublishRankSEO\Meta\SeoData::image_for_post( $post ) : null;
			$image = $found ? (string) $found['url'] : (string) get_option( 'publishrank_seo_default_social_image', '' );
			if ( $image ) {
				$image_id                   = function_exists( 'attachment_url_to_postid' ) ? absint( attachment_url_to_postid( $image ) ) : 0;
				$image_meta                 = $image_id ? wp_get_attachment_metadata( $image_id ) : array();
				$page['primaryImageOfPage'] = $this->image_object( $image, $url . '#primaryimage', is_array( $image_meta ) ? $image_meta : array() );
			}
		}
		return $page;
	}

	/** @return array<string, mixed> */
	private function article() {
		$post             = get_queried_object();
		$permalink        = esc_url_raw( (string) get_permalink( $post ) );
		$site_url         = trailingslashit( PublicationProfile::primary_url() );
		$author           = $post instanceof \WP_Post ? get_userdata( $post->post_author ) : false;
		$author_url       = $author ? (string) get_author_posts_url( $post->post_author ) : $site_url;
			$default_type = SchemaTypes::resolve_in( get_option( 'publishrank_schema_default_post_type', 'NewsArticle' ), SchemaTypes::default_article_types(), 'NewsArticle' );
			$schema_type  = SchemaTypes::resolve( PostMeta::get( $post->ID, PostMeta::SCHEMA_TYPE, $default_type ) );
			// Older releases stored broad values such as Report or Review. Never
			// pass those values through to JSON-LD: only the news-publisher article
			// allow-list (SchemaTypes::article_types) may be emitted for the article node.
		if ( ! array_key_exists( $schema_type, SchemaTypes::article_types() ) && 'WebStory' !== $schema_type ) {
			$schema_type = $default_type; }
		if ( 'WebStory' === $schema_type || $this->is_web_story_post( $post ) ) {
			$schema_type = 'Article'; }
			$schema_type = LiveBlogSchema::is_live_blog( $post ) ? 'LiveBlogPosting' : $schema_type;
			$seo             = \PublishRankSEO\Meta\SeoData::for_post( $post );
			$description     = isset( $seo['description'] ) ? (string) $seo['description'] : '';
			$description     = wp_strip_all_tags( $description );
		$author_node_id  = trailingslashit( $author_url ) . '#author';
		$identity        = $this->identity_entity();
		$article         = array(
			'@type'               => $schema_type,
			'@id'                 => trailingslashit( $permalink ) . '#article',
			'url'                 => $permalink,
			'headline'            => wp_strip_all_tags( (string) get_the_title( $post ) ),
			'description'         => $description,
			'datePublished'       => get_post_time( DATE_W3C, true, $post ),
			'dateModified'        => get_post_modified_time( DATE_W3C, true, $post ),
			'dateCreated'         => get_post_time( DATE_W3C, true, $post ),
			'inLanguage'          => \PublishRankSEO\Meta\LanguageAlternates::content_language( $post ),
			'isAccessibleForFree' => '1' !== (string) PostMeta::get( $post->ID, PostMeta::ACCESSIBLE_FOR_FREE, '1' ) ? false : true,
			'isPartOf'            => array( '@id' => $site_url . '#website' ),
			'author'              => array( '@id' => $author_node_id ),
			// Keep publisher data in the single shared identity node. Repeating name/logo here
			// allowed publication and organization settings to drift into conflicting values.
			'publisher'           => array( '@id' => $this->identity_id() ),
			'mainEntityOfPage'    => array( '@id' => trailingslashit( $permalink ) . '#webpage' ),
			'articleSection'      => $this->article_section( $post ),
			'genre'               => NewsroomSignals::genre( $post ),
			'articleBody'         => wp_trim_words( wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ), 500, '' ),
			'wordCount'           => \PublishRankSEO\Meta\LanguageAlternates::word_count( strip_shortcodes( (string) $post->post_content ) ),
			'copyrightYear'       => (int) get_post_time( 'Y', true, $post ),
			'copyrightHolder'     => array( '@id' => $this->identity_id() ),
		);
		$copyright_notice = trim( sanitize_textarea_field( (string) get_option( 'publishrank_copyright', '' ) ) );
		if ( '' !== $copyright_notice ) {
			$uses_current_year = false !== strpos( $copyright_notice, '%current_year%' );
			if ( $uses_current_year ) {
				$current_year = wp_date( 'Y' );
				$copyright_notice = str_replace( '%current_year%', $current_year, $copyright_notice );
				$article['copyrightYear'] = (int) $current_year;
			}
			$article['copyrightNotice'] = $copyright_notice;
		}
		$found        = \PublishRankSEO\Meta\SeoData::image_for_post( $post );
		$story_poster = $this->is_web_story_post( $post ) ? (string) PostMeta::get( $post->ID, PostMeta::WEB_STORY_POSTER, '' ) : '';
		$image        = $story_poster ? $story_poster : ( $found ? (string) $found['url'] : (string) get_option( 'publishrank_seo_default_social_image', '' ) );
		if ( $image ) {
			$image_id   = function_exists( 'attachment_url_to_postid' ) ? absint( attachment_url_to_postid( $image ) ) : 0;
			$image_meta = $image_id ? wp_get_attachment_metadata( $image_id ) : array();
			$image_node = $this->image_object( $image, trailingslashit( $permalink ) . '#primaryimage', is_array( $image_meta ) ? $image_meta : array() );
			$image_alt  = $image_id ? get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : '';
			if ( $image_alt ) {
				$image_node['caption'] = sanitize_text_field( $image_alt ); }
			$article['image'] = $image_node;
		}
			$keywords = $this->keywords( $post );
		if ( $keywords ) {
			$article['keywords'] = $keywords; }
			$citations = array_filter( array_map( 'esc_url_raw', preg_split( '/\r\n|\r|\n|,/', (string) PostMeta::get( $post->ID, PostMeta::CITATIONS, '' ) ) ) );
		if ( $citations ) {
			$article['citation'] = array_values( $citations ); }
		$video = $this->video_object( $post, $image );
		if ( $video ) {
			$article['video'] = $video; }
		$article = $this->news_article_details( $article, $post, $schema_type, $image );
		if ( 'ReviewNewsArticle' === $schema_type ) {
			$item_reviewed = SchemaBuilder::review_item( $post );
			if ( $item_reviewed ) {
				$article['itemReviewed'] = $item_reviewed;
				$rating = SchemaBuilder::review_rating( $post );
				if ( $rating ) {
					$article['reviewRating'] = $rating; }
				$article = SchemaBuilder::review_notes( $article, $post );
			}
		}
		$article = self::paywall( $article, $post );
		// Link translations of this article so search engines treat them as one story in several languages.
		$translations = \PublishRankSEO\Meta\LanguageAlternates::post_translations( $post->ID );
		if ( count( $translations ) > 1 ) {
			$others = array();
			foreach ( $translations as $translation_id ) {
				if ( (int) $translation_id !== (int) $post->ID ) {
					$others[] = array( '@id' => trailingslashit( (string) get_permalink( $translation_id ) ) . '#article' ); }
			}
			if ( $others ) {
				$article['workTranslation'] = $others; }
		}
		if ( 'LiveBlogPosting' === $schema_type ) {
			$article = LiveBlogSchema::decorate( $article, $post ); }
			// Speakable is opt-in: selectors depend on the theme, so none are invented. Return CSS selectors from this filter to enable it.
			$speakable = array_values( array_filter( array_map( 'sanitize_text_field', (array) apply_filters( 'publishrank_schema_speakable_selectors', array(), $post ) ) ) );
		if ( $speakable ) {
			$article['speakable'] = array(
				'@type'       => 'SpeakableSpecification',
				'cssSelector' => $speakable,
			); }
			return $article;
	}

	/**
	 * NewsArticle-family details (ReportageNewsArticle, AnalysisNewsArticle, …): dateline, where it was
	 * reported, what place it is about, backstory, corrections and thumbnail. Only real values are output.
	 *
	 * @param array<string,mixed> $article Article node.
	 * @param \WP_Post            $post    Post.
	 * @param string              $type    Resolved schema type.
	 * @param string              $image   Primary image URL.
	 * @return array<string,mixed>
	 */
	private function news_article_details( array $article, $post, $type, $image ) {
		$get      = static function ( $key ) use ( $post ) {
			return trim( sanitize_text_field( (string) get_post_meta( $post->ID, $key, true ) ) );
		};
		$is_news  = 'NewsArticle' === $type || 'NewsArticle' === substr( (string) $type, -11 );
		$dateline = $get( PostMeta::DATELINE );
		$location = $get( PostMeta::LOCATION_CREATED );
		$about    = $get( PostMeta::CONTENT_LOCATION );
		if ( '' === $dateline && '' !== $location && $is_news ) {
			// A dateline is the filing place; fall back to the reported-from place for news articles.
			$dateline = $location;
		}
		if ( '' !== $dateline ) {
			$article['dateline'] = $dateline;
		}
		if ( '' !== $location ) {
			$article['locationCreated'] = array( '@type' => 'Place', 'name' => $location );
		}
		if ( '' !== $about ) {
			$article['contentLocation'] = array( '@type' => 'Place', 'name' => $about );
		} elseif ( '' !== $location && 'ReportageNewsArticle' === $type ) {
			// Reportage is first-hand reporting: the story is about the place it was reported from unless told otherwise.
			$article['contentLocation'] = array( '@type' => 'Place', 'name' => $location );
		}
		$backstory = trim( sanitize_textarea_field( (string) get_post_meta( $post->ID, PostMeta::BACKSTORY, true ) ) );
		if ( '' !== $backstory && $is_news ) {
			$article['backstory'] = $backstory;
		}
		$correction = trim( sanitize_textarea_field( (string) get_post_meta( $post->ID, PostMeta::CORRECTION, true ) ) );
		if ( '' !== $correction ) {
			$article['correction'] = array(
				'@type'       => 'CorrectionComment',
				'text'        => $correction,
				'datePublished' => get_post_modified_time( DATE_W3C, true, $post ),
			);
		}
		if ( $image ) {
			$article['thumbnailUrl'] = esc_url_raw( $image );
		}
		if ( $is_news ) {
			$principles = PublicationProfile::publishing_principles();
			if ( ! empty( $principles['publishingPrinciples'] ) ) {
				$article['publishingPrinciples'] = $principles['publishingPrinciples'];
			}
		}
		return $article;
	}

	/** @return array<string, mixed> A stable author node connected to the article by @id. */
	private function article_author() {
		$post = get_queried_object();
		if ( ! $post instanceof \WP_Post ) {
			return array(); }
		$user       = get_userdata( $post->post_author );
		$author_url = $user ? (string) get_author_posts_url( $post->post_author ) : trailingslashit( PublicationProfile::primary_url() );
		$name       = PostMeta::get( $post->ID, PostMeta::AUTHOR_NAME, '' );
		if ( ! $name ) {
			$name = $user ? $user->display_name : __( 'Editorial staff', 'publishrank' ); }
		$node      = array(
			'@type' => 'Person',
			'@id'   => trailingslashit( $author_url ) . '#author',
			'name'  => wp_strip_all_tags( (string) $name ),
			'url'   => esc_url_raw( $author_url ),
		);
		$job_title = PostMeta::get( $post->ID, PostMeta::AUTHOR_JOB_TITLE, '' );
		$image     = PostMeta::get( $post->ID, PostMeta::AUTHOR_IMAGE, '' );
		if ( $job_title ) {
			$node['jobTitle'] = wp_strip_all_tags( (string) $job_title ); }
		if ( $user ) {
			$expertise = SchemaBuilder::author_expertise( $user->ID );
			if ( $expertise ) {
				$node['knowsAbout'] = $expertise; }
		}
		if ( $image ) {
			$node['image'] = $this->image_object( $image, trailingslashit( $author_url ) . '#author-image' ); } elseif ( $user && function_exists( 'get_avatar_url' ) ) {
			$node['image'] = esc_url_raw( get_avatar_url( $user->ID ) ); }
			return $node;
	}

	/** @param string $url @param string $id @param array $meta @return array<string, mixed> */
	private function image_object( $url, $id, $meta = array() ) {
		$clean = esc_url_raw( $url );
		$image = array(
			'@type'      => 'ImageObject',
			'@id'        => $id,
			'url'        => PublicationProfile::asset_url( $clean ),
			'contentUrl' => PublicationProfile::asset_url( $clean ),
		);
		if ( ! empty( $meta['width'] ) ) {
			$image['width'] = absint( $meta['width'] ); }
		if ( ! empty( $meta['height'] ) ) {
			$image['height'] = absint( $meta['height'] ); }
		$path     = (string) wp_parse_url( $clean, PHP_URL_PATH );
		$filetype = wp_check_filetype( $path );
		$mime     = ! empty( $filetype['type'] ) ? sanitize_text_field( $filetype['type'] ) : '';
		if ( $mime ) {
			$image['encodingFormat'] = $mime; }
		return $image;
	}

	/** @param \WP_Post $post @return string */
	private function keywords( $post ) {
		$terms = array();
		$tags  = get_the_tags( $post->ID );
		if ( is_array( $tags ) ) {
			$terms = array_merge( $terms, wp_list_pluck( $tags, 'name' ) ); }
		$categories = get_the_category( $post->ID );
		if ( is_array( $categories ) ) {
			$terms = array_merge( $terms, wp_list_pluck( $categories, 'name' ) ); }
		$focus = PostMeta::get( $post->ID, PostMeta::FOCUS_KEYWORD, '' );
		if ( $focus ) {
			$terms[] = wp_strip_all_tags( (string) $focus ); }
		$terms        = array_merge( $terms, PostMeta::get_list( $post->ID, PostMeta::SECONDARY_KEYPHRASES ), PostMeta::get_list( $post->ID, PostMeta::RELATED_TERMS ) );
		$entity_topic = PostMeta::get( $post->ID, PostMeta::ENTITY_TOPIC, '' );
		if ( $entity_topic ) {
			$terms[] = $entity_topic; }
		$terms = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $terms ) ) ) );
		return implode( ', ', $terms );
	}

	/** @param \WP_Post $post @param string $fallback_image @return array<string, mixed>|null */
	private function video_object( $post, $fallback_image ) {
		$thumbnail = (string) get_post_meta( $post->ID, PostMeta::VIDEO_THUMBNAIL, true );
		$duration  = (string) get_post_meta( $post->ID, PostMeta::VIDEO_DURATION, true );
		preg_match( '/https?:\/\/[^\s"\'<>]+\.(?:mp4|webm|mov)(?:\?[^\s"\'<>]+)?/i', (string) $post->post_content, $matches );
		$content_url = ! empty( $matches[0] ) ? esc_url_raw( $matches[0] ) : '';
		if ( ! $content_url || ! $thumbnail ) {
			return null; }
		$video = array(
			'@type'        => 'VideoObject',
			'@id'          => trailingslashit( (string) get_permalink( $post ) ) . '#video',
			'name'         => wp_strip_all_tags( (string) get_the_title( $post ) ),
			'description'  => ( function ( $seo ) {
				return isset( $seo['description'] ) ? (string) $seo['description'] : ''; } )( \PublishRankSEO\Meta\SeoData::for_post( $post ) ),
			'thumbnailUrl' => PublicationProfile::asset_url( $thumbnail ? $thumbnail : $fallback_image ),
			'uploadDate'   => get_post_time( DATE_W3C, true, $post ),
			'contentUrl'   => $content_url,
		);
		if ( $duration ) {
			$video['duration'] = sanitize_text_field( $duration ); }
		return $video;
	}

	/** @param \WP_Post $post @return string */
	private function article_section( $post ) {
		$categories = get_the_category( $post->ID );
		return ! empty( $categories ) ? (string) $categories[0]->name : __( 'News', 'publishrank' );
	}

	private function is_editorial_article() {
		$is = $this->is_editorial_article_default();
		return (bool) apply_filters( 'publishrank_is_editorial_article', $is, get_queried_object() );
	}

	private function is_editorial_article_default() {
		$post = get_queried_object();
		$type = $post instanceof \WP_Post ? get_post_type_object( $post->post_type ) : false;
		if ( ! is_singular() || ! $post instanceof \WP_Post || ! $type || ! $type->public ) {
			return false; }
		if ( 'attachment' === $post->post_type ) {
			return false; }
		$chosen = SchemaTypes::resolve( PostMeta::get( $post->ID, PostMeta::SCHEMA_TYPE, '' ) );
		if ( '' !== $chosen && ! array_key_exists( $chosen, SchemaTypes::article_types() ) && 'WebStory' !== $chosen ) {
			return false; }
		if ( 'page' === $post->post_type ) {
			// Pages are WebPage nodes unless the editor explicitly chose an article schema type for this page.
			return '' !== $chosen && array_key_exists( $chosen, SchemaTypes::article_types() );
		}
		return (bool) $type->publicly_queryable;
	}
	/** Detect the Web Stories editor profile or the common Web Stories plugin post types. */
	private function is_web_story_post( $post ) {
		if ( ! $post instanceof \WP_Post ) {
			return false; }
		$chosen = SchemaTypes::resolve( PostMeta::get( $post->ID, PostMeta::SCHEMA_TYPE, '' ) );
		return 'WebStory' === $chosen || in_array( $post->post_type, array( 'web-story', 'web_stories', 'web-story-page' ), true );
	}

	/** @return array<string, mixed>|null */
	private function collection_list() {
		global $wp_query;
		$posts = ( is_object( $wp_query ) && ! empty( $wp_query->posts ) && is_array( $wp_query->posts ) ) ? $wp_query->posts : array();
		if ( empty( $posts ) ) {
			return null; }
		$url   = trailingslashit( ( new \PublishRankSEO\Meta\MetaGenerator() )->canonical() );
		$items = array();
		foreach ( array_slice( $posts, 0, 20 ) as $index => $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue; }
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $index + 1,
				'url'      => esc_url_raw( (string) get_permalink( $post ) ),
				'name'     => wp_strip_all_tags( (string) get_the_title( $post ) ),
			);
		}
		return empty( $items ) ? null : array(
			'@type'           => 'ItemList',
			'@id'             => $url . '#itemlist',
			'numberOfItems'   => count( $items ),
			'itemListElement' => $items,
		);
	}

	/**
	 * Collapse duplicate nodes before output: nodes sharing an @id are merged (first value wins), when several supported article-type nodes describe the same URL only one primary
	 * entity is kept (LiveBlogPosting is preferred over NewsArticle/Article).
	 *
	 * @param array<int,array<string,mixed>> $graph
	 * @return array<int,array<string,mixed>>
	 */
	public static function dedupe_graph( array $graph ) {
		$article_types = array_keys( SchemaTypes::article_types() );
		$type_of       = static function ( $node ) {
			$t = $node['@type'] ?? '';
			return is_array( $t ) ? (string) reset( $t ) : (string) $t;
		};
		$by_id         = array();
		$out           = array();
		foreach ( $graph as $node ) {
			if ( ! is_array( $node ) ) {
				continue; }
			$id = isset( $node['@id'] ) ? (string) $node['@id'] : '';
			if ( '' !== $id && isset( $by_id[ $id ] ) ) {
				$out[ $by_id[ $id ] ] += $node;
				continue; }
			if ( '' !== $id ) {
				$by_id[ $id ] = count( $out ); }
			$out[] = $node;
		}
		// FAQPage is a singleton per URL too: keep the first node that carries it (the WebPage when a
		// visible FAQ exists) and drop further FAQPage nodes added by custom schema or graph filters.
		$faq_seen = false;
		foreach ( $out as $index => $node ) {
			$types = (array) ( $node['@type'] ?? array() );
			if ( in_array( 'FAQPage', $types, true ) ) {
				if ( $faq_seen ) {
					unset( $out[ $index ] );
				}
				$faq_seen = true;
			}
		}
		$out = array_values( $out );
		// BreadcrumbList is a singleton for the current document. A third-party
		// graph filter can add a second list with a different @id, so @id-only
		// deduplication is not sufficient here. Prefer the canonical current-page
		// list, then the list with the most usable items, and make every WebPage
		// breadcrumb reference point at the retained node.
		$breadcrumb_indexes = array();
		$canonical_breadcrumb_id = trailingslashit( ( new \PublishRankSEO\Meta\MetaGenerator() )->canonical() ) . '#breadcrumb';
		foreach ( $out as $index => $node ) {
			$type = $node['@type'] ?? '';
			$type = is_array( $type ) ? $type : array( $type );
			if ( in_array( 'BreadcrumbList', $type, true ) ) {
				$breadcrumb_indexes[] = $index;
			}
		}
		if ( count( $breadcrumb_indexes ) > 1 ) {
			$keep = reset( $breadcrumb_indexes );
			foreach ( $breadcrumb_indexes as $index ) {
				$current_score = ( (string) ( $out[ $index ]['@id'] ?? '' ) === $canonical_breadcrumb_id ? 1000000 : 0 ) + count( (array) ( $out[ $index ]['itemListElement'] ?? array() ) );
				$keep_score = ( (string) ( $out[ $keep ]['@id'] ?? '' ) === $canonical_breadcrumb_id ? 1000000 : 0 ) + count( (array) ( $out[ $keep ]['itemListElement'] ?? array() ) );
				if ( $current_score > $keep_score ) {
					$keep = $index;
				}
			}
			$kept_breadcrumb_id = (string) ( $out[ $keep ]['@id'] ?? $canonical_breadcrumb_id );
			$result = array();
			foreach ( $out as $index => $node ) {
				if ( in_array( $index, $breadcrumb_indexes, true ) && $index !== $keep ) {
					continue;
				}
				if ( isset( $node['breadcrumb']['@id'] ) ) {
					$node['breadcrumb']['@id'] = $kept_breadcrumb_id;
				}
				$result[] = $node;
			}
			$out = $result;
		}
		$primary_for = array();
		$drop        = array();
		foreach ( $out as $i => $node ) {
			$type = $type_of( $node );
			if ( in_array( $type, $article_types, true ) ) {
				$key = (string) ( $node['mainEntityOfPage']['@id'] ?? $node['url'] ?? '' );
				if ( '' === $key ) {
					continue; }
				if ( isset( $primary_for[ $key ] ) ) {
					$keep = $primary_for[ $key ];
					if ( 'LiveBlogPosting' === $type && 'LiveBlogPosting' !== $type_of( $out[ $keep ] ) ) {
						$drop[ $keep ]       = true;
						$primary_for[ $key ] = $i;
					} else {
						$drop[ $i ] = true; }
				} else {
					$primary_for[ $key ] = $i; }
			}
		}
		$result = array();
		foreach ( $out as $i => $node ) {
			if ( empty( $drop[ $i ] ) ) {
				$result[] = $node; }
		}
		return $result;
	}

	/**
	 * Paywall markup Google requires for subscription content: isAccessibleForFree=false plus a hasPart
	 * WebPageElement naming the CSS class that wraps the locked section, so it is not treated as cloaking.
	 *
	 * @param array<string,mixed> $article
	 * @return array<string,mixed>
	 */
	public static function paywall( array $article, $post ) {
		if ( ! isset( $article['isAccessibleForFree'] ) || false !== $article['isAccessibleForFree'] ) {
			return $article; }
		$selector = trim( (string) PostMeta::get( $post->ID, PostMeta::PAYWALL_SELECTOR, '' ) );
		$selector = '' === $selector ? '.paywall' : $selector;
		$selector = (string) apply_filters( 'publishrank_paywall_selector', $selector, $post );
		// Google accepts class selectors only.
		if ( ! preg_match( '/^\.[A-Za-z_][A-Za-z0-9_-]*$/', $selector ) ) {
			$selector = '.' . preg_replace( '/[^A-Za-z0-9_-]/', '', ltrim( $selector, '.' ) ); }
		if ( '.' === $selector ) {
			return $article; }
		$article['hasPart'] = array(
			'@type'               => 'WebPageElement',
			'isAccessibleForFree' => false,
			'cssSelector'         => $selector,
		);
		return $article;
	}

	/**
	 * ClaimReview for a fact-check article (https://developers.google.com/search/docs/appearance/structured-data/factcheck).
	 * Output only when the claim, a 1–5 rating and its verdict text are all filled in.
	 *
	 * @return array<string,mixed>|null
	 */
	public function claim_review( $post ) {
		if ( ! $post instanceof \WP_Post ) {
			return null; }
		$claim   = trim( wp_strip_all_tags( (string) PostMeta::get( $post->ID, PostMeta::CLAIM_TEXT, '' ) ) );
		$rating  = absint( PostMeta::get( $post->ID, PostMeta::CLAIM_RATING, '' ) );
		$verdict = trim( wp_strip_all_tags( (string) PostMeta::get( $post->ID, PostMeta::CLAIM_VERDICT, '' ) ) );
		if ( '' === $claim || $rating < 1 || $rating > 5 || '' === $verdict ) {
			return null; }
		$permalink = (string) get_permalink( $post );
		$base      = trailingslashit( $permalink );
		$item      = array( '@type' => 'Claim' );
		$who       = trim( wp_strip_all_tags( (string) PostMeta::get( $post->ID, PostMeta::CLAIM_AUTHOR, '' ) ) );
		if ( '' !== $who ) {
			$item['author'] = array( '@type' => 'Thing', 'name' => $who ); }
		$date = (string) PostMeta::get( $post->ID, PostMeta::CLAIM_DATE, '' );
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			$item['datePublished'] = $date; }
		$appearance = (string) PostMeta::get( $post->ID, PostMeta::CLAIM_APPEARANCE, '' );
		if ( '' !== $appearance ) {
			$item['appearance'] = array( '@type' => 'CreativeWork', 'url' => esc_url_raw( $appearance ) ); }
		$node = array(
			'@type'         => 'ClaimReview',
			'@id'           => $base . '#claimreview',
			'url'           => $permalink,
			'claimReviewed' => $claim,
			'datePublished' => get_post_time( DATE_W3C, true, $post ),
			'author'        => array( '@id' => $this->identity_id() ),
			'reviewRating'  => array(
				'@type'         => 'Rating',
				'ratingValue'   => $rating,
				'bestRating'    => 5,
				'worstRating'   => 1,
				'alternateName' => $verdict,
			),
			'itemReviewed'  => $item,
			'isPartOf'      => array( '@id' => $base . '#article' ),
		);
		return (array) apply_filters( 'publishrank_schema_claim_review', $node, $post );
	}
}
/* EOF */
